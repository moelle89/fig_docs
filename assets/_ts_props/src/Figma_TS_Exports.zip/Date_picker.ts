export interface Date_picker {
	month: string;
	actions: boolean;
	type: 'Single' | 'Single with help buttons' | 'Dual' | 'Dual with help buttons';
	showRange: 'False' | 'True';
}