export interface Date_cell {
	type: 'Date cell normal' | 'Current date cell' | 'Range start' | 'Range highlight' | 'Range end';
	state: 'Disabled' | 'Normal' | 'Hover';
}